package main

import "github.com/muhammedsirajudeen/startrix-cli/cmd"

func main() {
	cmd.Execute()
}
